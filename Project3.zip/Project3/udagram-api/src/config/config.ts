export const config = {
  'username': 'postgres',
  'password': 'duylk123456',
  'database': 'postgres',
  'host': 'cdr.cje2nmjuenj7.us-east-1.rds.amazonaws.com',
  'dialect': 'postgres',
  'aws_region': 'us-east-1',
  'aws_profile': 'default',
  'aws_media_bucket': 'pro3-196343632393',
  'url': 'http://localhost:8100',
  'jwt': {
    'secret': 'testing',
  },
};
